

    <script src="assets/js/vendors/jquery-3.7.1.min.js"></script>
    <script src="assets/js/vendors/bootstrap.bundle.min.js"></script>
    <script src="assets/js/vendors/masonry.pkgd.min.js" integrity="sha384-GNFwBvfVxBkLMJpYMOABq3c+d3KnQxudP/mGPkzpZSTYykLBNsZEnG2D9G/X/+7D" crossorigin="anonymous" async></script>
    <script src="assets/js/vendors/swiper-bundle.min.js"></script>
    <script src="assets/js/vendors/aos.js"></script>
    <script src="assets/js/vendors/wow.min.js"></script>
    <script src="assets/js/vendors/jquery.appear.js"></script>
    <script src="assets/js/vendors/jquery.odometer.min.js"></script>
    <script src="assets/js/vendors/headhesive.min.js"></script>
    <script src="assets/js/vendors/smart-stick-nav.js"></script>
    <script src="assets/js/vendors/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/vendors/gsap.min.js"></script>
    <script src="assets/js/vendors/ScrollToPlugin.min.js"></script>
    <script src="assets/js/vendors/ScrollTrigger.min.js"></script>
    <!-- Theme JS -->
    <script src="assets/js/gsap-custom.js"></script>
    <script src="assets/js/main.js"></script>
