    <!-- Favicon icon-->
    <link rel="shortcut icon" type="image/x-icon" href="assets/imgs/template/kronik_reduce.ico" />
    <!-- Libs CSS -->
    <link rel="stylesheet" href="assets/css/vendors/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/vendors/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/css/vendors/aos.css" />
    <link rel="stylesheet" href="assets/css/vendors/magnific-popup.css" />
    <link rel="stylesheet" href="assets/fonts/bootstrap-icons/bootstrap-icons.min.css" />
    <link rel="stylesheet" href="assets/fonts/boxicons/boxicons.min.css" />
    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/main.css" />

    